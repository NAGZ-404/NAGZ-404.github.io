public class HPBoost extends Enhancer{
    // private  int HPBoost; Not needed anymore
    
    //Constructor
    public HPBoost(String name, int HPBoost){
        super(name, "An enhancer that increases health", HPBoost);
        // this.HPBoost = HPBoost; Not needed anymore
    }
    
    // public int getHPBoostValue(){
        // return HPBoost;
    // } Not needed anymore
    
    //Modified to output information such as name, value and that it's for health
    @Override
    public void injectBoost(hero Player){
        Player.setHealth(Player.getHealth() + getEnhancerValue());
        System.out.println("\nYour health has increased by: " + getEnhancerValue());
    }
}