import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;
    
public class Game{
    public static void main(String[] args){
            //Generate enemies
            enemy Dax = new Boss("Dax");
            enemy Vas = new SmallFry("Vas");
            
            //Generate enhancers
            Enhancer UPP = new  HPBoost("UPP", 50);
            Enhancer Morphoid = new  DMGBoost("Morphoid", 50);
            
            // Create Rooms for the map and assign them to each location in newMap
            Room AbandWare = new Room("Abandoned Sentinel Warehouse", "50 years ago this place would've been stocked with Sentinels, it's empty now, the war took too much from us I guess.", Dax, null); 
            Room Homeless = new Room("Homeless Camp", "A homeless camp, possibly full of veterans that no one remembers, I wonder what this place has...", null, UPP);
            Room ProBar = new Room("Providence Bar", "Where the lawful and the lawless exchange goods, drinks and fists. Lovely place.", null, Morphoid);
            Room Central = new Room("Gate Office", "The office at the warehouse's gates, no one is here", null, null);
            Room BombedShop = new Room("Bombed Convenience Store", "Used to serve the common folk, now you can't find anything amongst the ashes, I'd be lucky if I found something", Vas, null);
            Map newMap = new Map(Central, AbandWare, BombedShop, Homeless, ProBar, null, null, null, null);
            
            
            Scanner scanner = new Scanner(System.in);
            String input;
            
            //Game title
            System.out.println("\n########################################################################################################################################");
            System.out.println("N.E.O.");
            System.out.println("########################################################################################################################################");
            
            //Redirects the player to enter name and choose which hero
            hero Player = HeroSelect();
            
            Player.setCurrentRoom(Central); //Sets the current room to be central 
            Boolean dead = Player.getStatus(); //Boolean variable to check if the player is dead or not
            
            while ( dead != true){
                Player.setCurrentRoom(Central);
                System.out.println("\n########################################################################################################################################");
                System.out.println("\n"+Player.getCurrentRoom().getRoomDescr()); //Return's room's description
                System.out.println("\n########################################################################################################################################");
                System.out.println("\nWhere do you want to go?"); //List of places the player can go
                System.out.println("type north for: " +newMap.getNorthRoom().getRoomName());
                System.out.println("type west for: " +newMap.getWestRoom().getRoomName());
                System.out.println("type east for: " +newMap.getEastRoom().getRoomName());
                System.out.println("type south for: " +newMap.getSouthRoom().getRoomName());
           
                input = scanner.nextLine();
                switch(input){ //Switch case makes it easier to implement responses to player's decisions in regards to the map
                    
                    case "north":
                    case "North":
                    case "Abandoned Sentinel Warehouse":
                    case "abandoned sentinel warehouse":
                    case "Abandoned Warehouse":
                    case "abandoned warehouse":
                    case "aw":{
                        goToNextPlace(Player, AbandWare);
                        break;
                    }
                    
                    case "west":
                    case "West":
                    case "Homeless Camp":
                    case "homeless camp":
                    case "hc":{
                        goToNextPlace(Player, Homeless);
                        break;
                    }
                    
                    case "east":
                    case "East":
                    case "Providence Bar":
                    case "providence bar":
                    case "pb":{
                        goToNextPlace(Player, ProBar);
                        break;
                    }
                    
                    case "south":
                    case "South":
                    case "Bombed Convenience Store":
                    case "Bombed Store":
                    case "bs":{
                        goToNextPlace(Player, BombedShop);
                        break;
                    }
                    
                    case "quit":
                    case "Quit":
                    case "exit":
                    case "Exit":{//Quits game
                        System.out.println("Do you want to leave the game?");
                        input = scanner.nextLine();
                        
                        if (input.equalsIgnoreCase("yes")){
                            System.exit(0);
                        }
                    }
                    
                    default:{
                        System.out.println("You typed in the wrong command");
                    }
                }
            }
    }
        
    public static hero goToNextPlace(hero Player, Room newRoom){//Method that takes player to another location
            Player.setCurrentRoom(newRoom); 
            Scanner scanner = new Scanner(System.in);
            
            System.out.println("\n########################################################################################################################################");
            System.out.println("\n" + newRoom.getRoomName() + ": "+newRoom.getRoomDescr());
            
                if (newRoom.getRoomEnemy() != null && newRoom.getRoomEnemy().getStatus() != true){
                    if (newRoom.getRoomEnemy() instanceof Boss){ //In case the player stubles upon the boss early
                        System.out.println("\nThere is a strong looking enemy in the room, maybe the boss of the gang around here, it's name is " + newRoom.getRoomEnemy().getName() +". I shouldn't fight him unprepared");
                    }
                    else{//For SmallFry types
                        System.out.println("\nThere is an enemy, it's name is " + newRoom.getRoomEnemy().getName() + ". I should be able to take it on.");
                    }
                    
                }
            
                else{//When there are no enemies
                    System.out.println("\nThere are no enemies to be seen");
                }
                
                if (newRoom.getEnhancer() != null){ //When there is an enhancer
                    System.out.println("\nThere is " + newRoom.getEnhancer().getEnhancerName() + " in the room, you can inject yourself it.");
                    //Outputs a different message depending on what type of enhancer it is
                    if (newRoom.getEnhancer() instanceof HPBoost){
                        System.out.println("It can increase your health by " + newRoom.getEnhancer().getEnhancerValue() + " points");
                    }
                    
                    if (newRoom.getEnhancer() instanceof DMGBoost){
                        System.out.println("It can increase your damage by " + newRoom.getEnhancer().getEnhancerValue() + " points");
                    }
                    
                    if (newRoom.getEnhancer() instanceof ARMBoost){
                        System.out.println("It can increase your defense by " + newRoom.getEnhancer().getEnhancerValue() + " points");
                    }
                }
            
    
            while (Player.getStatus() != true){   
                System.out.println("\n########################################################################################################################################");
                System.out.println("\nOptions:");
                System.out.println("\n########################################################################################################################################");
                System.out.println("1. Combat");
                System.out.println("2. Inject");
                System.out.println("3. Profile");
                System.out.println("4. Return");
                String input = scanner.nextLine();
                if (input.equals("1") || (input.equalsIgnoreCase("combat"))){ 
                    if (newRoom.getRoomEnemy() != null && newRoom.getRoomEnemy().getStatus() != true){
                        combat(Player, newRoom.getRoomEnemy()); //Directs to the combat() method
                    }
                    
                    else if (newRoom.getRoomEnemy() != null && newRoom.getRoomEnemy().getStatus() == true){
                        System.out.println("\nThe enemy, " + newRoom.getRoomEnemy().getName() + " is dead"); //If enemy is dead
                    }
        
                    else{
                        System.out.println("\nThere is nothing to fight"); //When there are no enemies
                    }
                }
                
                else if (input.equals("2") || (input.equalsIgnoreCase("inject"))){
                    if (newRoom.getEnhancer() != null){
                        newRoom.getEnhancer().injectBoost(Player); 
                        newRoom.removeEnhancer();
                    }
                    
                    else{
                        System.out.println("\nThere are no enhancers around to boost yourself with");
                    }
                }
                
                else if (input.equals("3") || (input.equalsIgnoreCase("profile"))){
                    Profile(Player); 
                }
                
                else if (input.equals("4") || (input.equalsIgnoreCase("return"))){
                    return Player;
                }

        }
        return null;
    }
    
    public static hero combat(hero Player, enemy Enemy){
        Scanner scanner = new Scanner(System.in);
        Boolean lowHealthAdv = false; //Necessary for the advMechanic() to kick in
        Boolean isBossDead = false; //To check if the Boss is dead
        
        String input;
        System.out.println("\n########################################################################################################################################");
        System.out.println("\nYou've engaged in a fight with: " +Enemy.getName());

        
        while (Enemy.getStatus() != true){
            int chance = ThreadLocalRandom.current().nextInt(1, (3+1)); //Randomises when SmallFry enemies is going to taunt
            
            System.out.println("\n########################################################################################################################################");
            System.out.println("\n" + Enemy.getName() + " -> Health: " +Enemy.getHealth());
            System.out.println("\n"+Player.getName() +" -> Health: "+ Player.getHealth());
            if (Player instanceof Sage){ //In case the Player chose Sage as the class
                System.out.println("\n"+ Player.getName() +" -> Mana: "+ ((Sage)Player).getMP());
            }
            
            System.out.println("\n########################################################################################################################################");
            System.out.println("\nMoves: ");
            
            if (Player instanceof Sage){ //In case the Player chose Sage as the class
                System.out.println("\n"+ Player.getName() +" -> Mana: "+ ((Sage)Player).getMP());
                System.out.println("1. "+ Player.getMove1Name() +" with up to " + Player.getMove1DMG() + " extra DMG -> MP: 5");
                System.out.println("2. "+ Player.getMove2Name() +" with up to " + Player.getMove2DMG() + " extra DMG -> MP: 10");
            }
            else{
                System.out.println("1. "+ Player.getMove1Name() +" with up to " + Player.getMove1DMG() + "extra DMG");
                System.out.println("2. "+ Player.getMove2Name() +" with up to " + Player.getMove2DMG() + "extra DMG");
            }
            
            input = scanner.nextLine();
            
            if (input.equalsIgnoreCase("1") || input.equalsIgnoreCase(Player.getMove1Name())){
                
                Player.move1(Enemy);
                System.out.println("\n########################################################################################################################################");
                if (Enemy.getHealth() < 1){
                    if (Enemy instanceof Boss){
                        isBossDead =  true;
                    }
                    System.out.println("\n########################################################################################################################################");
                    Player.increaseEXP(Enemy); //Increases EXP
                    System.out.println("\n" + Enemy.getName() + " is dead. You gained " + Player.getCurrentEXP() + " EXP");
                    Enemy.setStatus(true); //Sets death to true
                }
                
                else{
                    Enemy.enemyAttack(Player);
                    if (Enemy instanceof SmallFry && chance == 2){
                        ((SmallFry)Enemy).taunt(); //1 in 3 chance to taunt at you
                    }
                
                    if (Player.getHealth() < 1){
                        Player.setStatus(true); //Sets Player's death to true
                        GameOver(); //Game over screen
                    }    
                
                    else if ((Player.getHealth() < 20) && lowHealthAdv == false){
                        advMechanic(Player, Enemy); //If health drops below 20, activate advMechanic()
                        if (Enemy.getHealth() < 1){
                            Enemy.setStatus(true);
                        }
                        lowHealthAdv = true; //Sets to true so it doesn't repeat everytime
                    }
                
                }
            }
            
            if (input.equalsIgnoreCase("2") || input.equalsIgnoreCase(Player.getMove2Name())){
                Player.move2(Enemy);
                System.out.println("\n########################################################################################################################################");
                if (Enemy.getHealth() < 1){
                    if (Enemy instanceof Boss){
                        isBossDead =  true;
                    }
                    System.out.println("\n########################################################################################################################################");
                    Player.increaseEXP(Enemy);
                    System.out.println("\n" + Enemy.getName() + " is dead. You gained " + Player.getCurrentEXP() + " EXP");
                    Enemy.setStatus(true);
                }
                
                else{
                    Enemy.enemyAttack(Player);
                    if (Enemy instanceof SmallFry && chance == 2){
                        ((SmallFry)Enemy).taunt();
                    }
                
                    if (Player.getHealth() < 1){
                        Player.setStatus(true);
                        GameOver();
                    }       
                
                    else if ((Player.getHealth() < 20) && lowHealthAdv == false){
                        advMechanic(Player, Enemy);
                        if (Enemy.getHealth() < 1){
                            Enemy.setStatus(true);
                        }
                        lowHealthAdv = true;
                    }
                }
            }
        }
        
        System.out.println("\n########################################################################################################################################");
        if (Player instanceof Sage){ //Restores MP
            ((Sage)Player).restoreMP();
            System.out.println("\nYou've restored your MP back to: " +((Sage)Player).getMP());
        }
        
        if (Player instanceof Berserker && lowHealthAdv == true){ //Reverts buff
            ((Berserker)Player).revertBuff();
            System.out.println("\nYou have calmed down...");
        }
        
        if (isBossDead == true){ //Victory screen for the player, player also gain health for defeatig the boss
            ((Boss)Enemy).dropHealth(Player);
            VictoryScreen(Player);
        }
        return Player;
    }
    
    public static void advMechanic(hero Player, enemy Enemy){ //A mechanic that activates when the player is in a dire position, it benefits the player by activating a class specific skill
        System.out.println("\n########################################################################################################################################");
        if (Player instanceof Rounder){ //Lowers health
            System.out.println("\nYou've used PHYTA X on " + Enemy.getName() + "!");
            ((Rounder)Player).enemyDrug(Enemy);
            System.out.println("\n"+Player.getName() + " has lowered " +Enemy.getName()+"'s health down to "+Enemy.getHealth()+ ", I guess desperate times call for desperate measures");
        }
        
        if (Player instanceof Sage){ //Restores MP
            System.out.println(Player.getName() + " calls on the energy of the earth!");
            ((Sage)Player).clutchMPRestore();
            System.out.println("\n"+Player.getName() + " has restored MP to " +((Sage)Player).getMP() +" MP.");
        }
        
        if (Player instanceof Berserker){ //Increases strenght and defense
            System.out.println(Enemy.getName() + " has pushed " + Player.getName() + " too far!");
            ((Berserker)Player).berserkBuff();
            System.out.println("\n"+Player.getName() + " has entered its rage state, your DMG and DEF has risen to " + Player.getBaseDMG() + " and " + Player.getBaseDEF());
        }
    }
    
    public static void GameOver(){ //Game over screen
        System.out.println("\n########################################################################################################################################");
        System.out.println("Game Over");
        System.exit(0);
    }
    
    public static void VictoryScreen(hero Player){ //Victory screen that also displays stats of the player at the end of the game
        System.out.println("\n########################################################################################################################################");
        System.out.println("\nThe boss is dead, the gang terrorising the town has disbanded. But your mission is not over.");
        System.out.println(Player.getName() + " moves on, to extract his revenge, one day..."); 
        
        System.out.println("\n########################################################################################################################################");
        System.out.println("\nENDGAME STATS: ");
        System.out.println("\nName: " + Player.getName());
        System.out.println("\nClass: " + Player.getHeroClass());
        System.out.println("\n Health: " + Player.getHealth());
        System.out.println("DMG: "+ Player.getBaseDMG());
        System.out.println("DEF: "+ Player.getBaseDEF());
        System.out.println("EXP: "+ Player.getCurrentEXP());
        System.exit(0);
    }
    
    public static void Profile(hero Player){ //Allows the player to view their stats anytime they wish
        System.out.println("\n########################################################################################################################################");
        System.out.println("\nProfile");
        System.out.println("\n########################################################################################################################################");
        System.out.println("\nName: " + Player.getName());
        System.out.println("\nClass: " + Player.getHeroClass());
        System.out.println("\nDescription: " + Player.getDescr());
        System.out.println("\n Health: " + Player.getHealth());
        System.out.println("DMG: "+ Player.getBaseDMG());
        System.out.println("DEF: "+ Player.getBaseDEF());
        System.out.println("EXP: "+ Player.getCurrentEXP());
    }
    
    public static hero HeroSelect(){ //Allows player to enter their name and class
        Boolean confirm = false;
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n########################################################################################################################################");
        System.out.println("\nEnter your name:");
        String name = scanner.nextLine();
        
        while (!confirm == true){
            System.out.println("\nChoose a class: ");
            System.out.println("1. Rounder ");
            System.out.println("2. Sage ");
            System.out.println("3. Berserker ");
            System.out.println("4.Exit");
        
            String input = scanner.nextLine();
            
            if (input.equals("1") || input.equalsIgnoreCase("Rounder")){
               hero r = new Rounder(name); //Creates a temporary object to output info about the class
               
               System.out.println("\n########################################################################################################################################");
               System.out.println("\n"+ r.getHeroClass()); 
               System.out.println(r.getDescr());
               System.out.println("\n Health: " + r.getHealth());
               System.out.println("\n Armour: " + r.getBaseDEF());
               System.out.println("\n Base Damage: "+ r.getBaseDMG());
               System.out.println("\n Moves: ");
               System.out.println("\n -> "+ r.getMove1Name() +" with up to " + r.getMove1DMG() + " extra DMG");
               System.out.println("\n -> "+ r.getMove2Name() +" with up to " + r.getMove2DMG() + " extra DMG") ;
               System.out.println("Do you want this class? Yes or No");
               input = scanner.nextLine();
               
               if (input.equalsIgnoreCase("Yes")){
                   hero Player = new Rounder(name); //Substitution principle, assign the class of choice to the Player variable
                   confirm = true;
                   return Player;
                }
                
            }
            
            if (input.equals("2") || input.equalsIgnoreCase("Sage")){
               hero r = new Sage(name);
               
               System.out.println("\n########################################################################################################################################");
               System.out.println("\n"+ r.getHeroClass());
               System.out.println(r.getDescr());
               System.out.println("\n Health: " + r.getHealth());
               System.out.println("\n Armour: " + r.getBaseDEF());
               System.out.println("\n Base Damage: "+ r.getBaseDMG());
               System.out.println("\n Moves: ");
               System.out.println("\n -> "+ r.getMove1Name() +" with up to " + r.getMove1DMG() + " extra DMG and requires 5MP");
               System.out.println("\n -> "+ r.getMove2Name() +" with up to " + r.getMove2DMG() + " extra DMG and requires 10MP") ;
               System.out.println("Do you want this class? Yes or No");
               input = scanner.nextLine();
               
               if (input.equalsIgnoreCase("Yes")){
                   hero Player = new Sage(name);
                   confirm = true;
                   return Player;
                }
                
            }
            
            if (input.equals("3") || input.equalsIgnoreCase("Berserker")){
               hero r = new Berserker(name);
               
               System.out.println("\n########################################################################################################################################");
               System.out.println("\n"+ r.getHeroClass());
               System.out.println(r.getDescr());
               System.out.println("\n Health: " + r.getHealth());
               System.out.println("\n Armour: " + r.getBaseDEF());
               System.out.println("\n Base Damage: "+ r.getBaseDMG());
               System.out.println("\n Moves: ");
               System.out.println("\n -> "+ r.getMove1Name() +" with up to " + r.getMove1DMG() + " extra DMG");
               System.out.println("\n -> "+ r.getMove2Name() +" with up to " + r.getMove2DMG() + " extra DMG") ;
               System.out.println("Do you want this class? Yes or No");
               input = scanner.nextLine();
               
               if (input.equalsIgnoreCase("Yes")){
                   hero Player = new Berserker(name);
                   confirm = true;
                   return Player;
                }
                
            }
            
            if (input.equals("4") || input.equalsIgnoreCase("Exit")){
                System.out.println("\n########################################################################################################################################");
                System.out.println("Are you sure you want to exit? Yes or No");
                input = scanner.nextLine();
                
                if (input.equalsIgnoreCase("Yes")){
                   System.exit(0);
                }
            
            }

        }
        
        return null;
     }
}