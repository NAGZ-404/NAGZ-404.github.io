public class Room{
    //Basic attributes, also allows for an enemy and an item/enhancer to be stored
    private String name;
    private String descr;
    private enemy Enemy;
    private Enhancer Boost;

    //Constructor
    public Room(String name, String descr, enemy Enemy, Enhancer Boost){
        this.name = name;
        this.descr = descr;
        this.Enemy = Enemy;
        this.Boost = Boost;
        
    }
    
    //Getters
    public String getRoomName(){
        return name;
    }
        
    public String getRoomDescr(){
        return descr;
    }
    
    public Enhancer getEnhancer(){
        return Boost;
    }
    
    public enemy getRoomEnemy(){
        return Enemy;
    } 
    
    //Setter that allows for an enemy to be set
    public void setRoomEnemy(enemy newEnemy){
        Enemy = newEnemy;
    }
    
    //Technically a setter, allows for the addition of an enhancer in the room
    public void addEnhancer(Enhancer newBoost){
        Boost = newBoost;
    }
    
    //Removes the item from the room, usually used when the player picks the enhancer up
    public void removeEnhancer(){
        Boost = null;
    }
    
}