import java.util.concurrent.ThreadLocalRandom;

public final class Sage extends hero{
   //MP attributes unique to Sage
   private int MP;
   private final int MaxMP; //Total MP 
   
   //Constructor
   public Sage(String name){
       super(name, "Sage", 125, 25, 10, 0, false, "Knowledge is power. A mantra the Sage lives by. It's powers are unique yet extraordinary, perfect for survival in this hell.", "Agni Spark", 25, "Blitzkrieg", 50);
       MaxMP = 50;
       MP = MaxMP;
   }
   
   //Used in advMechanic(), restores MP to half of MaxMP
   public void clutchMPRestore(){
       setMP(MaxMP * (int)0.5);
    }
   
   //Overriden method with multiplier changed to 1.5
   @Override
    public void increaseEXP(enemy Enemy){
        int points = Enemy.getEXP();
        int EXP = getCurrentEXP();
        setCurrentEXP(EXP += points * 1.5);
    }
    
   //Setter that changes MP value in a fight
   public void setMP(int mp){
       MP = MP + mp;
   }
   
   //Restores MP to full after fight
   public void restoreMP(){
       MP = MaxMP;
   }
   
   //Getter that returns MP value
   public int getMP(){
       return MP;
   }
   
    //Move1 modified to suit Sage's damages and adjusted to the MP attribute
   @Override
    public enemy move1(enemy Enemy){
        int mp = -5;
        
        if (MP > 4){
            int damage = Math.max(0, ThreadLocalRandom.current().nextInt(getBaseDMG() - 15, (((getBaseDMG()+25)+1))) - Enemy.getBaseDEF());
            Enemy.setHealth(Enemy.getHealth()-damage);
            if (damage == 0){
                System.out.println("You missed!");
            }
            else{
                System.out.print("\nYou've dealt " + damage + " damage");
            }
            Enemy.setHealth(Math.max(0, Enemy.getHealth()));
            System.out.print("\n"+Enemy.getName()+" Health: " +Enemy.getHealth()+"\n");
            
            setMP(mp);
            return Enemy;
        }
        
        else{
            System.out.println("\n You don't have enough MP anymore");
            return Enemy;
        }
    }
   
   //Move2 modified to suit Sage's damages and adjusted to the MP attribute
   @Override
    public enemy move2(enemy Enemy){
        int mp = -10;
        
        if (MP > 9){
            int damage = Math.max(0, ThreadLocalRandom.current().nextInt(getBaseDMG(), ((getBaseDMG()+50)+1)) - Enemy.getBaseDEF());
            Enemy.setHealth(Enemy.getHealth()-damage);
            
            if (damage == 0){
                System.out.println("You missed!");
            }
            else{
                System.out.print("\nYou've dealt " + damage + " damage");
            }
            Enemy.setHealth(Math.max(0, Enemy.getHealth()));
            System.out.print("\n"+Enemy.getName()+" Health: " +Enemy.getHealth()+"\n");
        
            setMP(mp);
            return Enemy;
        }
        
        else{
            System.out.println("\n You don't have enough MP anymore");
            return Enemy;
        }

    }
}
