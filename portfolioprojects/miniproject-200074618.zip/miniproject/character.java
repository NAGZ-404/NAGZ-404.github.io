//The superclass of superclasses, contains the most basic attributes and methods for both hero and enemy, which pass it on into their subclasses
public abstract class character{
    
    //The persistent attributes in all classes passed down from character, basic properties such as name, health, etc...
    private String name;
    private int health;
    private int baseDMG; //The damage
    private int baseDEF; //How defense one has
    private Boolean death; //Flag thats important to check if either the character is dead or not, important for the hero and enemy subclasses
    
    
   //Constructor 
    public character(String name, int health, int baseDMG, int baseDEF, Boolean death){
        this.name = name;
        this.health = health;
        this.baseDMG = baseDMG;
        this.baseDEF = baseDEF;
        this.death = death;
    }
    
    
    //Getters
    public String getName(){
        return name;
    }
    
    public int getHealth(){
        return health;
    }
    
    public int getBaseDMG(){
        return baseDMG;
    }
    
    public int getBaseDEF(){
        return baseDEF;
    }
    
    public Boolean getStatus(){
        return death;
    }
    
    
    //Setters
    public void setHealth(int h){
        health = h;
    }
    
    public void setBaseDMG(int newBaseDMG){
        baseDMG = newBaseDMG;
    }
    
    
    public void setBaseDEF(int newBaseDEF){
        baseDEF = newBaseDEF;
    }
    
    
    public void setStatus(Boolean newStatus){
        death = newStatus;
    }
    
    
    
}