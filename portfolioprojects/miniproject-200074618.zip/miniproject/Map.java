public class Map{
    //All the rooms that can be put on the map
    
    private Room central;
    private Room north;
    private Room south;
    private Room west;
    private Room east;
    private Room northwest;
    private Room northeast;
    private Room southwest;
    private Room southeast;
    
    //Constructor
    public Map(Room central, Room north, Room south, Room west, Room east, Room northwest, Room northeast, Room southwest, Room southeast){
        this.central= central;
        this.north = north;
        this.south = south;
        this.west = west;
        this.east = east; 
        this.northwest = northwest;
        this.northeast = northeast;
        this.southwest = southwest;
        this.southeast = southeast;
        
    }
    
    
    //Getters for each room
    public Room getCentralRoom(){
        return central;
    }
    
    public Room getNorthRoom(){
        return north;
    }
    
    public Room getSouthRoom(){
        return south;
    }
    
    public Room getWestRoom(){
        return west;
    }
    
    public Room getEastRoom(){
        return east;
    }
    
    public Room getNWRoom(){
        return northwest;
    }
    
    public Room getNERoom(){
        return northeast;
    }
    
    public Room getSWRoom(){
        return southwest;
    }
    
    public Room getSERoom(){
        return southeast;
    }
}