public class DMGBoost extends Enhancer{
    // private int DMGBoost; Not needed
    
    //Constructor
    public DMGBoost(String name, int DMGBoost){
        super(name, "An enhancer that increases damage", DMGBoost);
        // this.DMGBoost = DMGBoost; Not needed
    }
    
    // public int getDMGBoostValue(){ Not needed
        // return DMGBoost;
    // }
    
    //Modified to output information such as name, value and that it's for damage
    @Override
    public void injectBoost(hero Player){
        if (Player instanceof Berserker){
            ((Berserker)Player).setNormalBaseDMG(((Berserker)Player).getNormalBaseDMG() + getEnhancerValue());
        }
        
        Player.setBaseDMG(Player.getBaseDMG() + getEnhancerValue());
        System.out.println("\nYour damage has increased by: " + getEnhancerValue());
    }
}