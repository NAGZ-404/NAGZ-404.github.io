import java.util.concurrent.ThreadLocalRandom;

public final class Berserker extends hero{
    //Attributes suited to Berserker
    private int rageFactor; 
    private int normalBaseDMG; //Actual baseDMG + enhancer effects
    private int normalBaseDEF; //Actual baseDEF + enhancer effects
    
    //Constructor
    public Berserker(String name){
        super(name, "Berserker", 200, 30, 0, 0, false, "Experimented soldiers that broke out of containment eons ago, now roam the world as tortured souls. Their rage will destroy anything and everything.", "C.H.A.R.G.E", 50, "Erazure", 60);  
        normalBaseDMG = 30;
        normalBaseDEF = 0;
    }
    
    //Increases Berserker's stats in advMechanic()
    public void berserkBuff(){
        rageFactor = ThreadLocalRandom.current().nextInt(2, 4+1);
        setBaseDMG(getBaseDMG() * rageFactor);
        setBaseDEF(getBaseDEF() + rageFactor);
    }
    
    //Restores stats to normal post-fight
    public void revertBuff(){
        setBaseDMG(normalBaseDMG);
        setBaseDEF(normalBaseDEF);
    }
    
    //Setters for normalBase(...) attributes
    public void setNormalBaseDMG(int newNormalBaseDMG){
        normalBaseDMG = newNormalBaseDMG;
    }
   
    public void setNormalBaseDEF(int newNormalBaseDEF){
        normalBaseDEF = newNormalBaseDEF;
    }
    
    //Getters for normalBase(...) attributes
    public int getNormalBaseDMG(){
        return normalBaseDMG;
    }
   
    public int getNormalBaseDEF(){
        return normalBaseDEF;
    }
   
    //Overriden method with multiplier changed to 1.2
    @Override
    public void increaseEXP(enemy Enemy){
        int points = Enemy.getEXP();
        int EXP = getCurrentEXP();
        setCurrentEXP(EXP += points * 1.2);
    }
    
    //Move1 modified to suit Berseker's damages
    @Override
    public enemy move1(enemy Enemy){
        int damage = Math.max(0, ThreadLocalRandom.current().nextInt(getBaseDMG(), ((getBaseDMG()+50)+1)) - Enemy.getBaseDEF());
        Enemy.setHealth(Enemy.getHealth()-damage);
        if (damage == 0){
                System.out.println("You missed!");
        }
        else{
                System.out.print("\nYou've dealt " + damage + " damage");
        }
        Enemy.setHealth(Math.max(0, Enemy.getHealth()));
        System.out.print("\n"+Enemy.getName()+" Health: " +Enemy.getHealth()+"\n");
        
        return Enemy;
    }
    
    //Move2 modified to suit Berseker's damages
    @Override
    public enemy move2(enemy Enemy){
        int damage = Math.max(0, ThreadLocalRandom.current().nextInt(getBaseDMG() + 15, ((getBaseDMG()+50)+1) - Enemy.getBaseDEF()));
        Enemy.setHealth(Enemy.getHealth()-damage);
        if (damage == 0){
                System.out.println("You missed!");
        }
        else{
                System.out.print("\nYou've dealt " + damage + " damage");
        }
        Enemy.setHealth(Math.max(0, Enemy.getHealth()));
        System.out.print("\n"+Enemy.getName()+" Health: " +Enemy.getHealth()+"\n");
        
        return Enemy;
    }
}