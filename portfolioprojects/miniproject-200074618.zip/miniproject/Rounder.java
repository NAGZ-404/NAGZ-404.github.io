import java.util.concurrent.ThreadLocalRandom;


public final class Rounder extends hero{
    
    //Property that allows for the advMechanic() to work in Game class for Rounder
    private int drugBoost;
    
    //Constructor
    public Rounder(String name){
       super(name, "Rounder", 100, 20, 15, 0, false, "The jack-of-all-trades mercenary roams the neon wasteland for coin. A balanced fighter that makes the most of his situations", "Nice Slice", 20, "Buck Shot", 30);
    }
    
    //The unique property given the value of 0.25 which is used to lower enemy's health by a quarter, invoked during advMechanic()
    public void enemyDrug(enemy Enemy){
        drugBoost = (int)0.25;
        Enemy.setHealth(Enemy.getHealth() - Enemy.getHealth()*drugBoost);
    }
    
    //Overriden method with multiplier changed to 2
    @Override
    public void increaseEXP(enemy Enemy){
        int points = Enemy.getEXP();
        int EXP = getCurrentEXP();
        setCurrentEXP(EXP += points * 2);
    }
    
    //Move1 modified to suit Rounder's damages
    @Override
    public enemy move1(enemy Enemy){
        int damage = Math.max(0, ThreadLocalRandom.current().nextInt(getBaseDMG() - 10, (((getBaseDMG()+20)+1))) - Enemy.getBaseDEF());
        Enemy.setHealth(Enemy.getHealth()-damage);
        if (damage == 0){
            System.out.println("You missed!");
        }
        else{
            System.out.print("\nYou've dealt " + damage + " damage");
        }
        Enemy.setHealth(Math.max(0, Enemy.getHealth()));
        System.out.print("\n"+Enemy.getName()+" Health: " +Enemy.getHealth()+"\n");
        
        return Enemy;
    }
    
    //Move2 modified to suit Rounder's damages
    @Override
    public enemy move2(enemy Enemy){
        int damage = Math.max(0, ThreadLocalRandom.current().nextInt(getBaseDMG() - 10, (((getBaseDMG()+30)+1))) - Enemy.getBaseDEF());
        Enemy.setHealth(Enemy.getHealth()-damage);
        if (damage == 0){
            System.out.println("You missed!");
        }
        else{
            System.out.print("\nYou've dealt " + damage + " damage");
        }
        Enemy.setHealth(Math.max(0, Enemy.getHealth()));
        System.out.print("\n"+Enemy.getName()+" Health: " +Enemy.getHealth()+"\n");
        
        return Enemy;
    }
}