public abstract class Enhancer{
    //Basic attributes for the items
    private String name;
    private String description;
    private  int Boost;
    
    //Constructor
    public Enhancer(String name, String description, int Boost){
        this.name = name;
        this.description = description;
        this.Boost = Boost;
    } 
    
    //Getters
    public String getEnhancerName(){
        return name;
    }
    
    public String getEnhancerDescription(){
        return description;
    }
    
    public int getEnhancerValue(){
        return Boost;
    }
    
    //Method to be overriden in subclasses
    public void injectBoost(hero Player){
        System.out.println("");
    }
}