import java.util.concurrent.ThreadLocalRandom;

public abstract class hero extends character{
    
    //Properties unique to the hero class
    private String heroClass; //Used for outputting which class the player has
    private String descr; //The description for each class, story purposes
    private int currentEXP; //Gauge of how much EXP one has
    private Room currentRoom; //Current location
    private String move1; //Name for move 1 for outputting info.
    private String move2; //Name for move 2 for outputting info.
    private int move1DMG; //Damage value for move 1 for outputting info.
    private int move2DMG; //Damage value for move 2 for outputting info.
    
    //Constructor
    public hero(String name, String heroClass, int health, int baseDMG, int baseDEF, int EXP, Boolean death, String descr, String move1, int move1DMG, String move2, int move2DMG){
       super(name, health, baseDMG, baseDEF, death);
       this.heroClass = heroClass;
       this.descr = descr;
       this.currentEXP = 0;
       this.currentRoom = currentRoom;
       this.move1 = move1;
       this.move2 = move2;
       this.move1DMG = move1DMG;
       this.move2DMG = move2DMG;
    }
    
    //Getters
    public String getDescr(){
        return descr;
    }
    
    public String getHeroClass(){
        return heroClass;
    }
    
    public int getCurrentEXP(){
        return currentEXP;
    }
    
    public String getMove1Name(){
        return move1;
    }
    
    public String getMove2Name(){
        return move2;
    }
       
    public int getMove1DMG(){
        return move1DMG;
    }
    
    public int getMove2DMG(){
        return move2DMG;
    }
     
    public Room getCurrentRoom(){
        return currentRoom;
    }
    
    //Setter for currentRoom
    public void setCurrentRoom(Room newRoom){
        currentRoom = newRoom;
    }
    
    public void setCurrentEXP(int EXP){
        currentEXP = EXP;
    }
    
    //Base increaseEXP() method
    public void increaseEXP(enemy Enemy){
        int points = Enemy.getEXP();
        currentEXP += points;
    }
    
    //Move methods
    public enemy move1(enemy Enemy){
        int damage = Math.max(0, ThreadLocalRandom.current().nextInt(getBaseDMG(), ((getBaseDMG())+1) - Enemy.getBaseDEF()));
        Enemy.setHealth(Enemy.getHealth()-damage);
        if (damage == 0){
                System.out.println("You missed!");
        }
        else{
                System.out.print("\nYou've dealt " + damage + " damage");
        }
        Enemy.setHealth(Math.max(0, Enemy.getHealth()));
        System.out.print("\n"+Enemy.getName()+" Health: " +Enemy.getHealth()+"\n");
        
        return Enemy;
    }
    
    public enemy move2(enemy Enemy){
        int damage = Math.max(0, ThreadLocalRandom.current().nextInt(getBaseDMG(), ((getBaseDMG())+1) - Enemy.getBaseDEF()));
        Enemy.setHealth(Enemy.getHealth()-damage);
        if (damage == 0){
                System.out.println("You missed!");
        }
        else{
                System.out.print("\nYou've dealt " + damage + " damage");
        }
        Enemy.setHealth(Math.max(0, Enemy.getHealth()));
        System.out.print("\n"+Enemy.getName()+" Health: " +Enemy.getHealth()+"\n");
        
        return Enemy;
    }
    
}