import java.util.concurrent.ThreadLocalRandom;

public final class SmallFry extends enemy{
    //An array of taunts only used for enemies of the SmallFry type
    private String[] taunts;
    
    //Constructor
    public SmallFry(String name){
       super(name, 50, 10, 5, false, 70);
       taunts = new String[]{"Pffft, weak punk", "All bark but no bite!", "What the hell is this?", "This is just sad", "Seriously you are wasting my time"};
    }
    
    //Taunt mechanic that randomly selects a taunt from the array
    public void taunt(){
        int randomTaunt = ThreadLocalRandom.current().nextInt(0, (4+1));
        System.out.println(getName() + ": '" + taunts[randomTaunt]+"'");
    }
    
    //Modified to suit the damages caused by a SmallFry
    @Override
    public hero enemyAttack(hero Player){
        
        int damage = Math.max(0, ThreadLocalRandom.current().nextInt(getBaseDMG() - 5, (((getBaseDMG()+10)+1))) - Player.getBaseDEF());
        Player.setHealth(Player.getHealth()-damage);
        System.out.print("\nYou received " + damage + " damage");
        System.out.print("\n"+Player.getName()+" Health: " +Player.getHealth()+"\n");
        return Player;
    }
}