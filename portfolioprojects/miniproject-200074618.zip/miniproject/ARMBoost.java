public class ARMBoost extends Enhancer{
    // private  int ARMBoost; Not needed
    
    public ARMBoost(String name, int ARMBoost){
        super(name, "An enhancer that increases defense", ARMBoost);
        // this.ARMBoost = ARMBoost; Not needed
    }
    
    // public int getARMBoostValue(){ Not needed
        // return ARMBoost;
    // }
    
    //Modified to output information such as name, value and that it's for defense
    @Override
    public void injectBoost(hero Player){
        if (Player instanceof Berserker){
            ((Berserker)Player).setNormalBaseDEF(((Berserker)Player).getNormalBaseDEF() + getEnhancerValue());
        }
        
        Player.setBaseDEF(Player.getBaseDEF() + getEnhancerValue());
        System.out.println("\nYour defense increased by: " + getEnhancerValue());
    }
}