import java.util.concurrent.ThreadLocalRandom;

public final class Boss extends enemy{
    //The boss drops this on defeat
    private Enhancer MEGA = new HPBoost("MEGA", 100);
    
    //Constructor
    public Boss(String name){
       super(name, 350, 25, 15, false, 100);
    }
    
    //Modified to suit the damages of the Boss.
    @Override
    public hero enemyAttack(hero Player){
        
        int damage = Math.max(0, ThreadLocalRandom.current().nextInt(getBaseDMG() - 20, (((getBaseDMG()+20)+1))) - Player.getBaseDEF());
        Player.setHealth(Player.getHealth()-damage);
        System.out.print("\nYou received " + damage + " damage");
        System.out.print("\n"+Player.getName()+" Health: " +Player.getHealth()+"\n");
        return Player;
    }
    
    //Activates when isBossDead == true in Game
    public void dropHealth(hero Player){
        System.out.print("\nThe boss dropped something, it's an enhancer.");
        System.out.print("\nIt's called " + MEGA.getEnhancerName() + ", you injected yourself with it...");
        MEGA.injectBoost(Player);
        System.out.print("\nYour health is now " + Player.getHealth() + "HP.");
    }
}