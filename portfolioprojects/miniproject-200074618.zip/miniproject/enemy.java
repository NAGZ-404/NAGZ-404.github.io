import java.util.concurrent.ThreadLocalRandom;

public abstract class enemy extends character{
    
    private int EXP; //Unique attribute of how much EXP an enemy has
    
    public enemy(String name, int health, int baseDMG, int baseDEF, Boolean death, int EXP){
       super(name, health, baseDMG, baseDEF, death);
       this.EXP= EXP;
    }
    
    //Getter for enemy's EXP
    public int getEXP(){
        return EXP;
    }
    
    //The normal attack method for enemy
    public hero enemyAttack(hero Player){
        int damage = ThreadLocalRandom.current().nextInt(0, (0));
        Player.setHealth(Player.getHealth()-damage);
        System.out.print("\nYou received " + damage + " damage");
        System.out.print("\n"+Player.getName()+" Health: " +Player.getHealth() +"\n");
        return Player;
    }
}