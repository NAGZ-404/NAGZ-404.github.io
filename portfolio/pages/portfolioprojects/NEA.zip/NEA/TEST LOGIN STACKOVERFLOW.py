def login():

    user0 = input("Username: ")
    pass0 = input("Password: ")

    file = open("account.txt","r")
    foundOne = False

    for line in file:
        details = line.split(",")
        # execute Check on each line, not only on last line    
        if user0 == details[0] and pass0 == details[1]:
            foundOne = True
            break # this will instantly leave the for loop of line checkings

    if foundOne == True:
        print("Correct!")
    else:
        print("Fail")

login()
