def UserLog():
    attempt = 0
    u= open("Login.txt", "r")
    for line in u:
        details = line.split(",")
        Username = details[0]
        Password = details[1]
#====================================================================================    

    User = input("Enter your username: ")
    while User != Username:
        print("Sorry this isn't the username")
        User = input("Enter your username: ")
        
    print("Username recognized")

    
    for Pass in range (1,4):
        attempt = attempt + 1
        Pass = input("Enter your password: ")
        if Pass == Password:
            print("Logged in!") 
            break

    if Pass != Password:
        print("ACCESS DENIED")
#=====================================================================================        
UserLog()
    
    
