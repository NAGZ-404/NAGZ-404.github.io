import time
import random

#=========================================================================================================================================================================================================================================================================
def HistoryEasyQuiz():
    score = 0
    i = open("HistoryEasyQuiz.txt","r")
    for line in i:
        detail = line.split(",")
    print(detail[0] +str("\n")+
          detail[1] +str("\n")+
          detail[2] +str("\n"))
        
    answer1 = input("What's your answer?")
    if answer1 == "b":
        print("Correct \n")
        score += 1
    else:
        print("Incorrect \n")

    print(detail[3] +str("\n")+
          detail[4] +str("\n")+
          detail[5] +str("\n"))
    
    answer2 = input("What's your answer?")
    if answer2 == "a":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[6] +str("\n")+
          detail[7] +str("\n")+
          detail[8] +str("\n"))
    
    answer3 = input("What's your answer?")
    if answer3 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[9] +str("\n")+
          detail[10] +str("\n")+
          detail[11] +str("\n"))
    
    answer4 = input("What's your answer?")
    if answer4 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[12] +str("\n")+
          detail[13] +str("\n")+
          detail[14] +str("\n"))
    
    answer5 = input("What's your answer?")
    if answer5 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")


#=========================================================================================================================================================================================================================================================================
def HistoryMediumQuiz():
    score = 0
    u = open("HistoryMediumQuiz.txt","r")
    for line in u:
        detail = u.readlines()
        detail = line.split(",")
    print(detail[0] +str("\n")+
          detail[1] +str("\n")+
          detail[2] +str("\n")+
          detail[3] +str("\n"))
        
    answer1 = input("What's your answer?")
    if answer1 == "b":
        print("Correct \n")
        score += 1
    else:
        print("Incorrect \n")

    print(detail[4] +str("\n")+
          detail[5] +str("\n")+
          detail[6] +str("\n")+
          detail[7] +str("\n"))
    
    answer2 = input("What's your answer?")
    if answer2 == "c":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[8] +str("\n")+
          detail[9] +str("\n")+
          detail[10] +str("\n")+
          detail[11] +str("\n"))
    
    answer3 = input("What's your answer?")
    if answer3 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[12] +str("\n")+
          detail[13] +str("\n")+
          detail[14] +str("\n")+
          detail[15] +str("\n"))
    
    answer4 = input("What's your answer?")
    if answer4 == "a":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[16] +str("\n")+
          detail[17] +str("\n")+
          detail[18] +str("\n")+
          detail[19] +str("\n"))
    
    answer5 = input("What's your answer?")
    if answer5 == "c":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print("Your score is " +str(score)+ " points")
    
        
#=========================================================================================================================================================================================================================================================================
def HistoryHardQuiz():
    score = 0 
    u = open("HistoryHardQuiz.txt","r")
    for line in u:
        detail = u.readlines()
        detail = line.split(",")
    print(detail[0] +str("\n")+
          detail[1] +str("\n")+
          detail[2] +str("\n")+
          detail[3] +str("\n")+
          detail[4] +str("\n"))
        
    answer1 = input("What's your answer?")
    if answer1 == "a":
        print("Correct \n")
        score += 1
    else:
        print("Incorrect \n")

    print(detail[5] +str("\n")+
          detail[6] +str("\n")+
          detail[7] +str("\n")+
          detail[8] +str("\n")+
          detail[9] +str("\n"))
    
    answer2 = input("What's your answer?")
    if answer2 == "c":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[10] +str("\n")+
          detail[11] +str("\n")+
          detail[12] +str("\n")+
          detail[13] +str("\n")+
          detail[14] +str("\n"))
    
    answer3 = input("What's your answer?")
    if answer3 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[15] +str("\n")+
          detail[16] +str("\n")+
          detail[17] +str("\n")+
          detail[18] +str("\n")+
          detail[19] +str("\n"))
    
    answer4 = input("What's your answer?")
    if answer4 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[20] +str("\n")+
          detail[21] +str("\n")+
          detail[22] +str("\n")+
          detail[23] +str("\n")+
          detail[24] +str("\n"))
    
    answer5 = input("What's your answer?")
    if answer5 == "a":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print("Your score is " +str(score)+ " points")
    


#=========================================================================================================================================================================================================================================================================

def GeoEasyQuiz():
    score = 0
    i = open("GeoEasyQuiz.txt","r")
    for line in i:
        detail = line.split(",")
    print(detail[0] +str("\n")+
          detail[1] +str("\n")+
          detail[2] +str("\n"))
        
    answer1 = input("What's your answer?")
    if answer1 == "a":
        print("Correct \n")
        score += 1
    else:
        print("Incorrect \n")

    print(detail[3] +str("\n")+
          detail[4] +str("\n")+
          detail[5] +str("\n"))
    
    answer2 = input("What's your answer?")
    if answer2 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[6] +str("\n")+
          detail[7] +str("\n")+
          detail[8] +str("\n"))
    
    answer3 = input("What's your answer?")
    if answer3 == "a":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[9] +str("\n")+
          detail[10] +str("\n")+
          detail[11] +str("\n"))
    
    answer4 = input("What's your answer?")
    if answer4 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[12] +str("\n")+
          detail[13] +str("\n")+
          detail[14] +str("\n"))
    
    answer5 = input("What's your answer?")
    if answer5 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print("Your score is " +str(score)+ " points")

#=========================================================================================================================================================================================================================================================================
def GeoMediumQuiz():
    score = 0 
    u = open("GeoMediumQuiz.txt","r")
    for line in u:
        detail = u.readlines()
        detail = line.split(",")
    print(detail[0] +str("\n")+
          detail[1] +str("\n")+
          detail[2] +str("\n")+
          detail[3] +str("\n"))
        
    answer1 = input("What's your answer?")
    if answer1 == "c":
        print("Correct \n")
        score += 1
    else:
        print("Incorrect \n")

    print(detail[4] +str("\n")+
          detail[5] +str("\n")+
          detail[6] +str("\n")+
          detail[7] +str("\n"))
    
    answer2 = input("What's your answer?")
    if answer2 == "a":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[8] +str("\n")+
          detail[9] +str("\n")+
          detail[10] +str("\n")+
          detail[11] +str("\n"))
    
    answer3 = input("What's your answer?")
    if answer3 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[12] +str("\n")+
          detail[13] +str("\n")+
          detail[14] +str("\n")+
          detail[15] +str("\n"))
    
    answer4 = input("What's your answer?")
    if answer4 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[16] +str("\n")+
          detail[17] +str("\n")+
          detail[18] +str("\n")+
          detail[19] +str("\n"))
    
    answer5 = input("What's your answer?")
    if answer5 == "c":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print("Your score is " +str(score)+ " points")            
#=========================================================================================================================================================================================================================================================================
def GeoHardQuiz():
    score = 0
    u = open("GeoHardQuiz.txt","r")
    for line in u:
        detail = u.readlines()
        detail = line.split(",")
    print(detail[0] +str("\n")+
          detail[1] +str("\n")+
          detail[2] +str("\n")+
          detail[3] +str("\n")+
          detail[4] +str("\n"))
        
    answer1 = input("What's your answer?")
    if answer1 == "b":
        print("Correct \n")
        score += 1
    else:
        print("Incorrect \n")

    print(detail[5] +str("\n")+
          detail[6] +str("\n")+
          detail[7] +str("\n")+
          detail[8] +str("\n")+
          detail[9] +str("\n"))
    
    answer2 = input("What's your answer?")
    if answer2 == "d":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[10] +str("\n")+
          detail[11] +str("\n")+
          detail[12] +str("\n")+
          detail[13] +str("\n")+
          detail[14] +str("\n"))
    
    answer3 = input("What's your answer?")
    if answer3 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[15] +str("\n")+
          detail[16] +str("\n")+
          detail[17] +str("\n")+
          detail[18] +str("\n")+
          detail[19] +str("\n"))
    
    answer4 = input("What's your answer?")
    if answer4 == "c":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[20] +str("\n")+
          detail[21] +str("\n")+
          detail[22] +str("\n")+
          detail[23] +str("\n")+
          detail[24] +str("\n"))
    
    answer5 = input("What's your answer?")
    if answer5 == "a":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print("Your score is " +str(score)+ " points")
#=========================================================================================================================================================================================================================================================================
def ScoreMenu():
    print (str(score))
    
#=========================================================================================================================================================================================================================================================================

def LevelSelec():
    print("To the level selection menu!")
    print("For Geography, press 1")
    print("For History, press 2")
    while True:
        TopicChoice=input("Make your choice:\n")
        
        if TopicChoice == "1":
            print("What difficulty do you prefer?")
            print("For easy mode, press 1")
            print("For medium mode, press 2")
            print("For hard mode, press 3")
            ModeChoice = input("Make your choice:\n")
            if ModeChoice == "1":
                GeoEasyQuiz()
                break
            elif ModeChoice == "2":
                GeoMediumQuiz()
                break
            elif ModeChoice == "3":
                GeoHardQuiz()
                break

        elif TopicChoice == "2":
            print("What difficulty do you prefer?")
            print("For easy mode, press 1")
            print("For medium mode, press 2")
            print("For hard mode, press 3")
            ModeChoice = input("Make your choice:\n")
            if ModeChoice == "1":
                HistoryEasyQuiz()
                break
            elif ModeChoice == "2":
                HistoryMediumQuiz()
                break
            elif ModeChoice == "3":
                HistoryHardQuiz()
                break
        else:
            print("Sorry, but that was not one of the available options, try again")
#=========================================================================================================================================================================================================================================================================Firstname=input("Enter your first name: ")

def UserReg():
    Firstname=input("Enter your first name: ")
    Surname=input("Enter your surname: ")
    Age=input("Enter your age: ")
    Form = input("Enter your form: ")
    Username = (Firstname [0:3] +(Age))
    Password=input("What would be your password?: ") 
    o = open("account.txt","a") 
    o.write(Username)
    o.write(",")
    o.write(Password)
    o.write(",")
    o.write(Firstname)
    o.write(",")
    o.write(Surname)
    o.write(",")
    o.write(Age)
    o.write(",")
    o.write(Form + "\n")
    print ("Your username is ", Username) 
    print("Your password is ", Password)
    print("This data has been saved onto the computer")
    o.close()

    print("Welcome", Firstname, Surname)
    LevelSelec()

    Menu()
#=========================================================================================================================================================================================================================================================================
def UserLog():
    attempt = 0
    u= open("account.txt", "r")
    FounduSer = False
    for line in u:
        details = line.split(",")
        Username = details[0]
        Password = details[1]
        

    User = input("Enter your username: ")
    while User != Username:
        print("Sorry this isn't the username")
        User = input("Enter your username: ")
        
    print("Username recognized")

    
    for Pass in range (1,4):
        attempt = attempt + 1
        Pass = input("Enter your password: ")
        if Pass == Password:
            print("Logged in!")
            print("Welcome!", details[2], details[3])
            LevelSelec()
            break

    if Pass != Password:
        print("ACCESS DENIED")

    Menu()
#=====================================================================================  

def Menu():
    print("Welcome to The Quiz! (Name still in alpha) \n")
    print("To register, press 1 \n")
    print("To login, press 2 \n")

    while True:
        selection = input("Enter your number:\n")
        if selection == "1":
                UserReg()
                break
        elif selection == "2":
                UserLog()
                break
        else:
            print("Please put in the available options, 1 or 2")
            
            

    
        
    
Menu()




