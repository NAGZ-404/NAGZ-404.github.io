def GeoEasyQuiz():
    score = 0
    i = open("GeoEasyQuiz.txt","r")
    for line in i:
        detail = line.split(",")
    print(detail[0] +str("\n")+
          detail[1] +str("\n")+
          detail[2] +str("\n"))
        
    answer1 = input("What's your answer?")
    if answer1 == "a":
        print("Correct \n")
        score += 1
    else:
        print("Incorrect \n")

    print(detail[3] +str("\n")+
          detail[4] +str("\n")+
          detail[5] +str("\n"))
    
    answer2 = input("What's your answer?")
    if answer2 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[6] +str("\n")+
          detail[7] +str("\n")+
          detail[8] +str("\n"))
    
    answer3 = input("What's your answer?")
    if answer3 == "a":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[9] +str("\n")+
          detail[10] +str("\n")+
          detail[11] +str("\n"))
    
    answer4 = input("What's your answer?")
    if answer4 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[12] +str("\n")+
          detail[13] +str("\n")+
          detail[14] +str("\n"))
    
    answer5 = input("What's your answer?")
    if answer5 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print("Your score is " +str(score)+ " points")

#=========================================================================================================================================================================================================================================================================
def GeoMediumQuiz():
    score = 0 
    u = open("GeoMediumQuiz.txt","r")
    for line in u:
        detail = u.readlines()
        detail = line.split(",")
    print(detail[0] +str("\n")+
          detail[1] +str("\n")+
          detail[2] +str("\n")+
          detail[3] +str("\n"))
        
    answer1 = input("What's your answer?")
    if answer1 == "c":
        print("Correct \n")
        score += 1
    else:
        print("Incorrect \n")

    print(detail[4] +str("\n")+
          detail[5] +str("\n")+
          detail[6] +str("\n")+
          detail[7] +str("\n"))
    
    answer2 = input("What's your answer?")
    if answer2 == "a":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[8] +str("\n")+
          detail[9] +str("\n")+
          detail[10] +str("\n")+
          detail[11] +str("\n"))
    
    answer3 = input("What's your answer?")
    if answer3 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[12] +str("\n")+
          detail[13] +str("\n")+
          detail[14] +str("\n")+
          detail[15] +str("\n"))
    
    answer4 = input("What's your answer?")
    if answer4 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[16] +str("\n")+
          detail[17] +str("\n")+
          detail[18] +str("\n")+
          detail[19] +str("\n"))
    
    answer5 = input("What's your answer?")
    if answer5 == "c":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print("Your score is " +str(score)+ " points")            
#=========================================================================================================================================================================================================================================================================
def GeoHardQuiz():
    score = 0 
    u = open("GeoHardQuiz.txt","r")
    for line in u:
        detail = u.readlines()
        detail = line.split(",")
    print(detail[0] +str("\n")+
          detail[1] +str("\n")+
          detail[2] +str("\n")+
          detail[3] +str("\n")+
          detail[4] +str("\n"))
        
    answer1 = input("What's your answer?")
    if answer1 == "b":
        print("Correct \n")
        score += 1
    else:
        print("Incorrect \n")

    print(detail[5] +str("\n")+
          detail[6] +str("\n")+
          detail[7] +str("\n")+
          detail[8] +str("\n")+
          detail[9] +str("\n"))
    
    answer2 = input("What's your answer?")
    if answer2 == "d":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[10] +str("\n")+
          detail[11] +str("\n")+
          detail[12] +str("\n")+
          detail[13] +str("\n")+
          detail[14] +str("\n"))
    
    answer3 = input("What's your answer?")
    if answer3 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[15] +str("\n")+
          detail[16] +str("\n")+
          detail[17] +str("\n")+
          detail[18] +str("\n")+
          detail[19] +str("\n"))
    
    answer4 = input("What's your answer?")
    if answer4 == "c":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[20] +str("\n")+
          detail[21] +str("\n")+
          detail[22] +str("\n")+
          detail[23] +str("\n")+
          detail[24] +str("\n"))
    
    answer5 = input("What's your answer?")
    if answer5 == "a":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print("Your score is " +str(score)+ " points")
#=========================================================================================================================================================================================================================================================================
def LevelSelec():
    print("Welcome to the level selection menu!")
    print("For Geography, press 1")
    print("For History, press 2")
    while True:
        TopicChoice=input("Make your choice:\n")
        
        if TopicChoice == "1":
            print("What difficulty do you prefer?")
            print("For easy mode, press 1")
            print("For medium mode, press 2")
            print("For hard mode, press 3")
            ModeChoice = input("Make your choice:\n")
            if ModeChoice == "1":
                GeoEasyQuiz()
                break
            elif ModeChoice == "2":
                GeoMediumQuiz()
                break
            elif ModeChoice == "3":
                GeoHardQuiz()
                break

        elif TopicChoice == "2":
            print("Sorry this mode is unavailable right now")

LevelSelec()
    
