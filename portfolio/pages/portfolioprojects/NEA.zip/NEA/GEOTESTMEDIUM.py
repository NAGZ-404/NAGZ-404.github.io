def GeoMediumQuiz():
    score = 0
    u = open("GeoMediumQuiz.txt","r")
    for line in u:
        detail = u.readlines()
        detail = line.split(",")
    print(detail[0] +str("\n")+
          detail[1] +str("\n")+
          detail[2] +str("\n")+
          detail[3] +str("\n"))
        
    answer1 = input("What's your answer?")
    if answer1 == "c":
        print("Correct \n")
        score += 1
    else:
        print("Incorrect \n")

    print(detail[4] +str("\n")+
          detail[5] +str("\n")+
          detail[6] +str("\n")+
          detail[7] +str("\n"))
    
    answer2 = input("What's your answer?")
    if answer2 == "a":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[8] +str("\n")+
          detail[9] +str("\n")+
          detail[10] +str("\n")+
          detail[11] +str("\n"))
    
    answer3 = input("What's your answer?")
    if answer3 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[12] +str("\n")+
          detail[13] +str("\n")+
          detail[14] +str("\n")+
          detail[15] +str("\n"))
    
    answer4 = input("What's your answer?")
    if answer4 == "b":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print(detail[16] +str("\n")+
          detail[17] +str("\n")+
          detail[18] +str("\n")+
          detail[19] +str("\n"))
    
    answer5 = input("What's your answer?")
    if answer5 == "c":
            print("Correct \n")
            score += 1
    else:
            print("Incorrect \n")

    print("Your score is " +str(score)+ " points")
            
GeoMediumQuiz()

