def Score():
    global score
    Percentage = (int(score) / 5 * 100)
    print ("Your percentage is: " +str(Percentage)+ "%")
    if score == 0:
        print("You got grade U")
        
    elif score < 2:
        print("You got grade C")
    elif score < 3:
        print("You got grade B")
    elif score < 4:
        print("You got grade A")
    elif score == 5:
        print ("You got grade A*")
